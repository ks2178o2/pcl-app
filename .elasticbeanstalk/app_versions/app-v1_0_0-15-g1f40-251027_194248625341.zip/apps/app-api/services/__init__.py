# apps/app-api/services/__init__.py
"""
Services package for PCL Product API
"""

__version__ = "1.0.0"

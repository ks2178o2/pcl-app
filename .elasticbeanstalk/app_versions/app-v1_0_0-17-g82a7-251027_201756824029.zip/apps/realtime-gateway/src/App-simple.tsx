import React from 'react'

function App() {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>Sales Angel Buddy - Test</h1>
      <p>If you can see this, the React app is working!</p>
      <div style={{ background: '#f0f0f0', padding: '10px', margin: '10px 0' }}>
        <h3>Status: ✅ React App Loading Successfully</h3>
      </div>
    </div>
  )
}

export default App
